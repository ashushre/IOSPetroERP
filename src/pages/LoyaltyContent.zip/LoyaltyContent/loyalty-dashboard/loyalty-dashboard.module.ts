import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LoyaltyDashboardPage } from './loyalty-dashboard';

@NgModule({
  declarations: [
    LoyaltyDashboardPage,
  ],
  imports: [
    IonicPageModule.forChild(LoyaltyDashboardPage),
  ],
})
export class LoyaltyDashboardPageModule {}
